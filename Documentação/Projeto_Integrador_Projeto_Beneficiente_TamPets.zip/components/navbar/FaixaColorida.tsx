import styles from '@/styles/faixacolorida.module.css';

export default function FaixaColorida() {
    return (
        <>
            <div className={styles.faixa} />
        </>
    );
}