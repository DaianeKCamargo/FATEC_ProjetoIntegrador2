// simulando um banco de dados com dados estáticos dos cachorros e gatos castrados 

import { label } from "framer-motion/m";

// e a quantidade de tampinhas arrecadadas, de 3 anos
export const relatorioData = [
    { month: 1, year: 2025, dog: 15, cat: 7, caps: 3500 },
    { month: 2, year: 2025, dog: 18, cat: 9, caps: 4000 },
    { month: 3, year: 2025, dog: 20, cat: 10, caps: 4500 },
    { month: 4, year: 2025, dog: 16, cat: 8, caps: 3800 },
    { month: 5, year: 2025, dog: 22, cat: 11, caps: 5000 },
    { month: 6, year: 2025, dog: 19, cat: 9, caps: 4200 },
    { month: 7, year: 2025, dog: 21, cat: 12, caps: 4800 },
    { month: 8, year: 2025, dog: 17, cat: 7, caps: 3900 },
    { month: 9, year: 2025, dog: 23, cat: 13, caps: 5200 },
    { month: 10, year: 2025, dog: 18, cat: 9, caps: 4100 },
    { month: 11, year: 2025, dog: 24, cat: 11, caps: 5500 },

    { month: 1, year: 2024, dog: 5, cat: 2, caps: 800 },
    { month: 2, year: 2024, dog: 7, cat: 3, caps: 1200 },
    { month: 3, year: 2024, dog: 10, cat: 6, caps: 2000 },
    { month: 4, year: 2024, dog: 8, cat: 4, caps: 1600 },
    { month: 5, year: 2024, dog: 12, cat: 5, caps: 2200 },
    { month: 6, year: 2024, dog: 9, cat: 3, caps: 1400 },
    { month: 7, year: 2024, dog: 11, cat: 7, caps: 2500 },
    { month: 8, year: 2024, dog: 6, cat: 2, caps: 1300 },
    { month: 9, year: 2024, dog: 13, cat: 8, caps: 2700 },
    { month: 10, year: 2024, dog: 7, cat: 4, caps: 1500 },
    { month: 11, year: 2024, dog: 14, cat: 6, caps: 3000 },
    { month: 12, year: 2024, dog: 10, cat: 5, caps: 2000 },

    { month: 1, year: 2023, dog: 4, cat: 1, caps: 600 },
    { month: 2, year: 2023, dog: 9, cat: 2, caps: 1500 },
    { month: 3, year: 2023, dog: 6, cat: 4, caps: 1800 },
    { month: 4, year: 2023, dog: 5, cat: 2, caps: 900 },
    { month: 5, year: 2023, dog: 8, cat: 3, caps: 1300 },
    { month: 6, year: 2023, dog: 7, cat: 2, caps: 1100 },
    { month: 7, year: 2023, dog: 10, cat: 5, caps: 2000 },
    { month: 8, year: 2023, dog: 5, cat: 1, caps: 800 },
    { month: 9, year: 2023, dog: 11, cat: 6, caps: 2200 },
    { month: 10, year: 2023, dog: 6, cat: 3, caps: 1400 },
    { month: 11, year: 2023, dog: 12, cat: 4, caps: 2500 },
    { month: 12, year: 2023, dog: 8, cat: 2, caps: 1600 }
];

// simulando um banco de dados com dados estáticos da redução do CO2, de 3 anos
export const relatorioCo2 = [
    { month: 1, year: 2025, co2: 120 },
    { month: 2, year: 2025, co2: 140 },
    { month: 3, year: 2025, co2: 160 },
    { month: 4, year: 2025, co2: 150 },
    { month: 5, year: 2025, co2: 170 },
    { month: 6, year: 2025, co2: 165 },
    { month: 7, year: 2025, co2: 180 },
    { month: 8, year: 2025, co2: 175 },
    { month: 9, year: 2025, co2: 190 },
    { month: 10, year: 2025, co2: 185 },
    { month: 11, year: 2025, co2: 200 },

    { month: 1, year: 2024, co2: 80 },
    { month: 2, year: 2024, co2: 90 },
    { month: 3, year: 2024, co2: 100 },
    { month: 4, year: 2024, co2: 95 },
    { month: 5, year: 2024, co2: 110 },
    { month: 6, year: 2024, co2: 105 },
    { month: 7, year: 2024, co2: 120 },
    { month: 8, year: 2024, co2: 115 },
    { month: 9, year: 2024, co2: 130 },
    { month: 10, year: 2024, co2: 125 },
    { month: 11, year: 2024, co2: 140 },
    { month: 12, year: 2024, co2: 145 },

    { month: 1, year: 2023, co2: 60 },
    { month: 2, year: 2023, co2: 70 },
    { month: 3, year: 2023, co2: 80 },
    { month: 4, year: 2023, co2: 75 },
    { month: 5, year: 2023, co2: 90 },
    { month: 6, year: 2023, co2: 85 },
    { month: 7, year: 2023, co2: 100 },
    { month: 8, year: 2023, co2: 95 },
    { month: 9, year: 2023, co2: 110 },
    { month: 10, year: 2023, co2: 100 },
    { month: 11, year: 2023, co2: 120 },
    { month: 12, year: 2023, co2: 130 },
];

// pega o nome dos meses para exibir nos filtros de acordo com o número do mês
export const mesesFiltro = [
    { value: 1, label: "Janeiro" },
    { value: 2, label: "Fevereiro" },
    { value: 3, label: "Março" },
    { value: 4, label: "Abril" },
    { value: 5, label: "Maio" },
    { value: 6, label: "Junho" },
    { value: 7, label: "Julho" },
    { value: 8, label: "Agosto" },
    { value: 9, label: "Setembro" },
    { value: 10, label: "Outubro" },
    { value: 11, label: "Novembro" },
    { value: 12, label: "Dezembro" }
];