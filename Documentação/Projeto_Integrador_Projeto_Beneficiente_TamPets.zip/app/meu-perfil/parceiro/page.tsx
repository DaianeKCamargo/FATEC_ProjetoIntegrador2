'use client'

export default function MeuPerfilParceiro() {

    return (
        <section>
            <div>
                <h1> Meu perfil Parceiros </h1>
            </div>
        </section>
    );
}