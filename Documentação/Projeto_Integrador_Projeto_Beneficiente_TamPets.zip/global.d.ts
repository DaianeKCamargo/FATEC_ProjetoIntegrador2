declare module 'bootstrap/dist/css/bootstrap.min.css';
// Diz ao typescript que css não precisa de tipos

declare module '*.css';
// Diz que qualquer tipo de css é válido

declare module "swiper/css";
declare module "swiper/css/pagination";